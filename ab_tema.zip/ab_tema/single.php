<?php get_header(  ); ?>

<main id="single" class="single">
  <div class="container">

  </div>
</main>

<?php get_footer(  ); ?>