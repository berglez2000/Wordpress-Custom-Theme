<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo get_the_title(  ); ?></title>
  <link rel="favicon" href="<?php echo get_site_icon_url(  ); ?>">

  <?php wp_head(  ); ?>
</head>
<body>
<div class="loading_page">
  <div class="loader"></div>
</div>
<header id="header" class="header">
  
</header>