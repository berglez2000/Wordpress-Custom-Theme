<?php get_header(  ); ?>

<main id="404" class="404">
  <div class="container">
    
  </div>
</main>

<?php get_footer(  ); ?>