<footer id="footer" class="footer">

</footer>

<?php wp_footer(  ); ?>
</body>
</html>