const main = () => {
  /* Loader */
  const loader = document.querySelector(".loading_page");
  loader.classList.add("hide");
}

window.addEventListener("load", main);