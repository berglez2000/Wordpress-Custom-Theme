<?php get_header(  ); ?>

<main id="search" class="search">
  <div class="container">
  
  </div>
</main>

<?php get_footer(  ); ?>