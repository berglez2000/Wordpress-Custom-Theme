<?php 

// Naloudaj CSS
function load_css(){
  wp_register_style( 'style', get_template_directory_uri(  ) . '/assets/css/style.css', array(), false, 'all' );
  wp_enqueue_style( 'style' );
}
add_action( 'wp_enqueue_scripts', 'load_css' );

// Naloudaj JS
function load_js(){
  wp_register_script( 'app', get_template_directory_uri(  ) . '/assets/js/app.js', array(), false, true );
  wp_enqueue_script( 'app' );
}
add_action('wp_enqueue_scripts', 'load_js');

// Tema ima dostop do menija
register_nav_menus(
  array(
  'header_menu' => __( 'Header Menu' ),
  )
);


// Dodaj options page
if(function_exists('acf_add_options_page')){
  acf_add_options_page(
    array(
      'page_title' => 'Nastavitve',
      'menu_title' => 'Nastavitve',
      'menu_slug' => 'nastavitve',
      'capability' => 'edit_posts'
    )
  );
}

// Registracija Blokov
if(function_exists('acf_register_block_type')){
  add_action( 'acf/init', 'register_acf_block_types' );
}
function register_acf_block_types(){
  // Primer registracije enega bloka
  /* acf_register_block_type(
    array(
      'name' => 'banner',
      'title' => __('Banner'),
      'description' => __('A Custom Block Type'),
      'render_template' => 'blocks/banner.php',
      'icon' => 'editor-paste-text',
    )
  ); */
}

// Custom Post Types
function custom_post_types(){
  // Primer registracije enega custom post typa
  /* $args = array(
    'labels' => array(
      'name' => 'Video',
      'singular_name' => 'Video',
    ),
    'hierarchical' => false, 
    'public' => true,
    'has_archive' => true,
    'supports' => array('editor', 'title'),
    'show_in_rest' => true,
    'menu_icon' => 'dashicons-video-alt2'
  );

  register_post_type( 'video', $args ); */
}
add_action( 'init', 'custom_post_types' );


// Dodaj Uredniku pravice
// Dodaj vlogo Urednika
$role_object = get_role( 'editor' );

// Dodaj mu možnost urejevanja teme
$role_object->add_cap( 'edit_theme_options' );
?>