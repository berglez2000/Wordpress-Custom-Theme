<?php get_header(  ); ?>

<main id="front-page" class="front-page page">
  <div class="container">

  </div>
</main>

<?php get_footer(  ); ?>