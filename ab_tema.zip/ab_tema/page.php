<?php get_header(  ); ?>

<main id="page" class="page">
  <div class="container">

  </div>
</main>

<?php get_footer(  ); ?>